<?php

namespace App\Http\Controllers;

use App\Http\Controllers\API\IResponseCodes;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController {
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    /**
     * @param null $msg
     *
     * @return JsonResponse
     */
    public function unAuthorizedResponse( $msg = null ) {
        if ( $msg ) {
            return response()->json( [
                'message'    => $msg,
                'status' => IResponseCodes::UNAUTHORISED
            ] );
        }

        return response()->json( [
            'message'    => trans('User Unauthorized!'),
            'status' => IResponseCodes::UNAUTHORISED
        ] );

    }

    /**
     * @param null $msg
     * @param null $errors
     *
     * @return JsonResponse
     */
    public function parametersInvalidResponse( $msg = null, $errors = null ) {
        if ( $msg ) {
            if ( $errors ) {
                return response()->json( [
                    'message'    => $msg,
                    'errors' => $errors,
                    'status' => IResponseCodes::UNPROCESSABLE_ENTITY
                ] );
            }

            return response()->json( [
                'message'    => $msg,
                'status' => IResponseCodes::UNPROCESSABLE_ENTITY
            ] );
        }
        if ( $errors ) {
            return response()->json( [
                'message'    => trans('Parameters Invalid!'),
                'errors' => $errors,
                'status' => IResponseCodes::UNPROCESSABLE_ENTITY
            ] );
        }

        return response()->json( [
            'message'    => trans('Parameters Invalid!'),
            'status' => IResponseCodes::UNPROCESSABLE_ENTITY
        ] );

    }

    /**
     * @param null $msg
     * @param null $data
     *
     * @return JsonResponse
     */
    public function successResponse( $msg = null, $data = null ): JsonResponse
    {
        if ( $msg ) {
            if ( $data ) {
                return response()->json( [
                    'message'    => $msg,
                    'data'   => $data,
                    'status' => IResponseCodes::SUCCESS
                ] );
            }

            return response()->json( [
                'message'    => $msg,
                'status' => IResponseCodes::SUCCESS
            ] );
        }
        if ( $data ) {
            return response()->json( [
                'message'    => trans('Operation Successful!'),
                'data'   => $data,
                'status' => IResponseCodes::SUCCESS
            ] );
        }

        return response()->json( [
            'message'    => trans('Operation Successful!'),
            'status' => IResponseCodes::SUCCESS
        ] );

    }
}
