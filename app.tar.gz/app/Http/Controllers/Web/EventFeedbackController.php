<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\EventFeedback;
use App\Services\EventFeedbackService;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\Session;
use Illuminate\View\View;

class EventFeedbackController extends Controller
{
    /** @var EventFeedbackService */
    private $service;
    /** @var string  */
    private $backRoute = '/event_feedback';

    /**
     *  EventFeedbackController constructor.
     */

    public function __construct()
    {
        $this->middleware('auth');
        $this->service = new EventFeedbackService();
    }

    /**
     * @return Application|Factory|View
     */
    public function index()
    {
        return view('event_feedback.index')
            ->with([
                'items' => $this->service->getAll(20),
            ]);
    }

    /**
     * @param $id
     * @return Application|Factory|View
     */

    public function show($id)
    {
        return view('event_feedback.show')
            ->with([
                'item' => $this->service->findById($id)
            ]);
    }

    /**
     * @param $id
     * @return Application|RedirectResponse|Redirector
     */
    public function destroy($id)
    {
        $this->service->remove($id);
        // Set flash
        Session::flash('success', 'Successfully Removed!');

        return redirect($this->backRoute);
    }
}
