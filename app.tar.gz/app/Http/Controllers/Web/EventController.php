<?php

namespace App\Http\Controllers\Web;

use App\Forms\Event\CreateEventForm;
use App\Forms\Event\UpdateEventForm;
use App\Http\Controllers\Controller;
use App\Services\EventService;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use App\Models\Event;
use App\Models\EventImage;
use Validator;

class EventController extends Controller
{
    /** @var EventService */
    private $service;

    /** @var string */
    private $backRoute = '/events';
    private $relations=[];



    /**
     * EventController constructor.
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->service = new EventService();
    }

    /**
     * @return Application|Factory|View
     */
    public function index()
    {
        $items = $this->service->getAll(20);
        return view('events.index')
            ->with(
                [
                    'items' => $items,
                ]
            );
    }

    /**
     * @return Application|Factory|View
     */
    public function create()
    {
        return view('events.create');
    }

    /**
     * @param Request $request
     * @return JsonResponse
     * @throws ValidationException
     */
    public function store(Request $request): JsonResponse
    {
        if (auth()->id()) {

            $validated = Validator::make($request->all(), [
                'images' => 'required|array',
                'images.*' => 'mimes:jpeg,jpg,png|max:10000',
            ]);
            if ($validated->fails()) {
                return $this->parametersInvalidResponse(null, $validated->errors()->all());
            }

            $form = new CreateEventForm();
            $form->loadFromArray($request->all());

            $item = $this->service->store($form);
            if ($item) {
                if (isset($request['images'])) {
                    $this->service->uploadImages($request['images'], $item['id']);
                }
                return $this->successResponse(
                    trans('Event added Successfully!'),
                    $item->load($this->relations)
                );
            }
        }
        return $this->unAuthorizedResponse();
    }

    /**
     * @param $id
     * @return Application|Factory|View
     */
    public function show($id)
    {
        return view('events.show')
            ->with([
                'item' => $this->service->findById($id)
            ]);
    }

    /**
     * @param $id
     * @return Application|Factory|View
     */
    public function edit($id)
    {
        return view('events.edit')
            ->with([
                'item' => $this->service->findById($id)
            ]);
    }

    /**
     * @param Request $request
     * @param $id
     * @return JsonResponse
     * @throws ValidationException
     */

    public function update(Request $request, $id): JsonResponse
    {
        $form = new UpdateEventForm();
        $form->loadFromArray($request->all());
        $items = $this->service->update($form, $id);

        $msg = 'Event updated successfully!';
        Session::flash('success', $msg);

        return response()->json(
            [
                'type' => 'success',
                'msg' => $msg,
                'data' => $items
            ]
        );
    }

    /**
     * @param $id
     * @return Application|RedirectResponse
     */
    public function destroy($id)
    {
        $this->service->remove($id);

        // Set flash
        Session::flash('success', 'Successfully Removed!');

        // Redirect to users
        return redirect($this->backRoute);
    }


}
