<?php

namespace App\Http\Controllers\Web;
use App\Forms\Feedback\CreateFeedBackForm;
use App\Forms\Feedback\UpdateFeedBackForm;
use App\Http\Controllers\Controller;
use App\Services\FeedBackService;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class FeedBackController extends Controller
{
    /** @var FeedBackService */
    private $service;
    /** @var string  */
    private $backRoute = 'feedback';

    /**
     *  FeedBackController constructor.
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->service = new FeedBackService();
    }

    /**
     * @return Application|Factory|View
     */

   public function index()
   {
       return view('feedback.index')->with([
            'items' =>$this->service->getAll(20),
       ]);
   }
    /**
     * @return Application|Factory|View
     */
    public function create()
    {
        return view('feedback.create');
    }

    /**
     * @param Request $request
     * @return JsonResponse
     * @throws ValidationException
     */

    public function store(Request $request): JsonResponse
    {
        $form = new CreateFeedBackForm();
        $form->loadFromArray($request->all());
        $item = $this->service->store($form);
        $msg = 'Ads added successfully!';
        Session::flash('success', $msg);

        return response()->json(
            [
                'type' => 'success',
                'msg' => $msg,
                'data' => $item
            ]
        );
    }

    public function show($id)
    {
        return view('feedback.show')->with([
            'item'=>$this->service->findById($id),
        ]);
    }

    /**
     * @param $id
     * @return Application|Factory|View
     */
    public function edit($id)
    {
        return view('feedback.edit')
            ->with([
                'item' => $this->service->findById($id)
            ]);
    }

    /**
     * @param Request $request
     * @param $id
     * @return JsonResponse
     * @throws ValidationException
     */
    public function update(Request $request, $id): JsonResponse
    {
        $form = new UpdateFeedBackForm();
        $form->loadFromArray($request->all());
        $items = $this->service->update($form, $id);

        $msg = 'Feedback updated successfully!';
        Session::flash('success', $msg);

        return response()->json(
            [
                'type' => 'success',
                'msg' => $msg,
                'data' => $items
            ]
        );
    }

    public function destroy($id)
    {
        $this->service->remove($id);

        Session::flash('success', 'Successfully Removed!');
        return redirect($this->backRoute);
    }
}
