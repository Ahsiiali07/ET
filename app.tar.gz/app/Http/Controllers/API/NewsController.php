<?php

namespace App\Http\Controllers\API;


use App\Services\NewsService;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class NewsController extends Controller {
    /**
     * @var NewsService $service
     */
    private $service;
    private $relation = [];


    public function __construct() {
        $this->service = new NewsService();
    }

    /**
     * @return JsonResponse
     */

    public function get(): JsonResponse {
        $res = $this->service->getAll(10);

        if ( $res ) {

            return $this->successResponse( trans( 'Operation Successful!' ), $res );
        }

        return $this->parametersInvalidResponse();
    }

    /**
     * @param $id
     *
     * @return JsonResponse
     */

    public function fetch( $id ) {
        $item = $this->service->findById( $id );
        if ( $item ) {
            return $this->successResponse( trans( 'Operation Successful!' ), $item );
        }

        return $this->parametersInvalidResponse();
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function filter( Request $request ): JsonResponse {
        $services = $this->service->filter( $request->all(), $request->per_page ?? null );

        if ( $services ) {

            return $this->successResponse( null, $services->load( $this->relation ) );
        }

        return $this->successResponse( 'No Article Found!' );
    }
}
