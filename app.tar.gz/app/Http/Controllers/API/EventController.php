<?php

namespace App\Http\Controllers\API;

use App\Forms\Event\CreateEventForm;
use App\Forms\Event\UpdateEventForm;
use App\Http\Controllers\Controller;
use App\Services\EventService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\ValidationException;
use Validator;

class EventController extends Controller {
    /** @var EventService $service */
    private $service;
    private $relations = [];


    public function __construct() {
        $this->service = new EventService();
    }

    /**
     * @return JsonResponse
     */

    public function get(): JsonResponse {
        $res = $this->service->getAll(10);

        if ( $res ) {

            return $this->successResponse( trans( 'Operation Successful!' ), $res );
        }

        return $this->parametersInvalidResponse();

    }

    /**
     * @param $id
     *
     * @return JsonResponse
     */
    public function fetch( $id ): JsonResponse {
        $item = $this->service->findById( $id );
        if ( $item ) {
            return $this->successResponse( trans( 'Operation Successful!' ), $item );
        }

        return $this->parametersInvalidResponse();
    }
}
