<?php

namespace App\Services;

use App\Models\Ad;

class AdService extends BaseService
{
    /**
     * AdService constructor.
     */
    public function __construct()
    {
        $this->model = new Ad();
        parent::__construct();
    }

    /** @var $model */
    public $model;
}
