<?php

namespace App\Services;

use App\Forms\IForm;
use App\Helpers\GeneralHelper;
use App\Models\Publication;
use Illuminate\Validation\ValidationException;

class PublicationService extends BaseService
{
    /**
     * PublicationService constructor.
     */
   public function __construct()
   {
       $this->model= new Publication();
       parent::__construct();
   }
   /** @var $model */
    public $model;

    /**
     * @param IForm $form
     *
     * @return mixed
     * @throws ValidationException
     */
    public function store( IForm $form ) {
        // Validate Form
        $form->validate();

        $model = $this->model;

        // Assign values to model attributes
        $form->loadToModel( $model );
        if ( isset( $form->file ) ) {
            $user->file = GeneralHelper::uploadFile( $form->file, 'files/users' );
        }

        $model->save();

        return $model;
    }
}
