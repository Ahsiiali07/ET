<?php

namespace App\Services;


interface ISupportService {

    const OPEN_SUPPORT_REQUEST = 0;
    const CLOSED_SUPPORT_REQUEST = 1;
}
