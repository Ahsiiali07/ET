<?php

namespace App\Services;

use App\Forms\IForm;
use App\Helpers\GeneralHelper;
use App\Models\Shop;
use Illuminate\Validation\ValidationException;

class ShopService extends BaseService
{
    /**
     * ShopService constructor.
     */
    public function __construct()
    {
        $this->model = new Shop();
        parent::__construct();
    }

    /** @var $model */
    public $model;

    /**
     * @param IForm $form
     *
     * @return mixed
     * @throws ValidationException
     */
    public function store(IForm $form)
    {
        // Validate Form
        $form->validate();

        $model = $this->model;

        // Assign values to model attributes
        $form->loadToModel($model);
        if (isset($form->image_url)) {
            $form->image_url = GeneralHelper::uploadImageManual($form->image_url, 'images/shop');
        }

        $model->save();

        return $model;
    }

    /**
     * @param array $data
     * @return mixed
     */
    public function search(array $data)
    {
        $query = $this->model;
        if (isset($data['lat'])) {
            $query = $query->where('lat', 'LIKE', '%' . $data['lat'] . '%');
        }
        if (isset($data['lng'])) {
            $query = $query->where('lng', 'LIKE', '%' . $data['lng'] . '%');
        }
        return $query->get();
    }
}
