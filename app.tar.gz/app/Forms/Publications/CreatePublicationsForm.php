<?php

namespace App\Forms\Publications;
/**
 * @property string $course
 * @property string $pdf
 * @property string $type
 * @property string $category_id
 */
class CreatePublicationsForm extends \App\Forms\BaseForm {

    /* @var $course */
    public $course;

    /* @var $pdf */
    public $pdf;

    /* @var $type */
    public $type;

    /* @var $category_id */
    public $category_id;

    /**
     * @inheritDoc
     */
    public function toArray() {
        return [
            'course'      => $this->course,
            'pdf'         => $this->pdf,
            'type'        => $this->type,
            'category_id' => $this->category_id,


        ];
    }

    /**
     * @inheritDoc
     */
    public function rules() {
        return [
            'course'      => 'required',
            'pdf'         => 'required',
            'type'        => 'required',
            'category_id' => 'required',


        ];
    }
}
