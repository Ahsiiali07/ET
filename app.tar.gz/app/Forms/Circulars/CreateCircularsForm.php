<?php

namespace App\Forms\Circulars;

/**
 * @property string $is_new
 * @property string $company_name
 * @property int $image_url
 */
class CreateCircularsForm extends \App\Forms\BaseForm {

    /* @var $is_new */
    public $is_new;


    /* @var $company_name */
    public $company_name;

    /* @var $image_url */
    public $image_url;

    /**
     * @inheritDoc
     */
    public function toArray() {
        return [
            'is_new'       => $this->is_new,
            'company_name' => $this->company_name,
            'image_url'    => $this->image_url,

        ];
    }

    /**
     * @inheritDoc
     */
    public function rules() {
        return [
            'is_new'       => 'required',
            'company_name' => 'required',
            'image_url'    => 'required',
        ];
    }
}
