<?php

namespace App\Forms\EventCategory;
/**
 * @property string $name_en
 * @property string $name_sp
 * @property string $image_url
 */
class updateEventCategoryForm extends \App\Forms\BaseForm
{
    /* @var $name_en */
    public $name_en;
    /* @var $name_sp */
    public $name_sp;
    /* @var $image_url */
    public $image_url;


    /**
     * @inheritDoc
     */
    public function toArray()
    {
        return [
            'name_en' => $this->name_en,
            'name_sp' => $this->name_sp,
            'image_url'=>$this->image_url,

        ];
    }

    /**
     * @inheritDoc
     */
    public function rules()
    {
        return [
        ];
    }
}
