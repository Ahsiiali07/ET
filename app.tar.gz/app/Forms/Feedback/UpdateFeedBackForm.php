<?php

namespace App\Forms\Feedback;
/**
 *  @property string $email
 * @property string $title_en
 * @property string $title_sp
 * @property string $description_en
 * @property string $description_sp
 */
class UpdateFeedBackForm extends \App\Forms\BaseForm
{
    /* @var $email */
    public $email;
    /* @var $title_en */
    public $title_en;
    /* @var $title_sp */
    public $title_sp;
    /* @var $description_en */
    public $description_en;
    /* @var $description_sp */
    public $description_sp;
    /**

    /**
     * @inheritDoc
     */
    public function toArray()
    {
        return [
            'email' => $this->email,
            'title_en' => $this->title_en,
            'title_sp' => $this->title_sp,
            'description_en' => $this->description_en,
            'description_sp' => $this->description_sp,

        ];
    }

    /**
     * @inheritDoc
     */
    public function rules()
    {
        return[
            'email' => 'required',
            'title_en' => 'required',
            'title_sp' => 'required',
            'description_en' => 'required',
            'description_sp' => 'required',
        ];
    }
}
