<?php

namespace App\Forms\Category;
/**
 * @property string $name_en
 * @property string $name_sp
 * @property string $image_url
 * @property string $old_image_url
 * @property int $parent_category_id
 */
class UpdateCategoryForm extends \App\Forms\BaseForm {
    /* @var $name_en */
    public $name_en;

    /* @var $name_sp */
    public $name_sp;

    /* @var $image_url */
    public $image_url;
    
      /* @var $old_image_url */
    public $old_image_url;

    /* @var $parent_category_id */
    public $parent_category_id;

    /**
     * @inheritDoc
     */
    public function toArray() {
        return [
            'name_en'            => $this->name_en,
            'name_sp'            => $this->name_sp,
            'image_url'          => $this->image_url,
            'old_image_url'      => $this->old_image_url,
            'parent_category_id' => $this->parent_category_id,
        ];
    }

    /**
     * @inheritDoc
     */
    public function rules() {
        return [
            'name_en' => 'required',
            'name_sp' => 'required',

        ];
    }
}
