<?php

namespace App\Forms\Shops;
/**
 * @property string $name_en
 * @property string $name_sp
 * @property string $description_en
 * @property string $description_sp
 * @property string $do_notify
 * @property string $lat
 * @property string $lng
 * @property int $image_url
 */
class CreateShopsForm extends \App\Forms\BaseForm {
    /* @var $name_en */
    public $name_en;

    /* @var $name_sp */
    public $name_sp;

    /* @var $description_en */
    public $description_en;

    /* @var $description_sp */
    public $description_sp;

    /* @var $do_notify */
    public $do_notify;

    /* @var $lat */
    public $lat;

    /* @var $lng */
    public $lng;

    /* @var $image_url */
    public $image_url;

    /**
     * @inheritDoc
     */
    public function toArray() {
        return [
            'name_en'        => $this->name_en,
            'name_sp'        => $this->name_sp,
            'description_en' => $this->description_en,
            'description_sp' => $this->description_sp,
            'do_notify'      => $this->do_notify,
            'lat'            => $this->lat,
            'lng'            => $this->lng,
            'image_url'      => $this->image_url,

        ];
    }

    /**
     * @inheritDoc
     */
    public function rules() {
        return [
            'name_en'        => 'required',
            'name_sp'        => 'required',
            'description_en' => 'required',
            'description_sp' => 'required',
            'do_notify'      => 'required',
            'lat'            => 'required',
            'lng'            => 'required',
            'image_url'      => 'required',

        ];
    }
}
