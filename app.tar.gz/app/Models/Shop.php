<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property string $name_en
 * @property string $name_sp
 * @property string $description_en
 * @property string $description_sp
 * @property string $image_url
 * @property string $do_notify
 * @property string $lat
 * @property string $lng
 */
 
class Shop extends Model
{
    protected $table = 'shops';
    protected $fillable = [
        'name_en',
        'name_sp',
        'description_en',
        'description_sp',
        'image_url',
        'do_notify',
        'lat',
        'lng',
    ];


}
