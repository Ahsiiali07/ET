<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;

/**
 * @property string $name_en
 * @property string $name_sp
 * @property string $image_url
 */
class Category extends Model {

    use Notifiable, ModelHelper;
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name_en',
        'name_sp',
        'image_url',
        'parent_category_id',
    ];

    /**
     * @return HasMany
     */
    public function sub_categories(): HasMany {
        return $this->hasMany( __CLASS__, 'parent_category_id' );
    }

    /**
     * @return BelongsTo
     */
    public function parent_category(): BelongsTo {
        return $this->belongsTo( __CLASS__, 'parent_category_id' );
    }

    /**
     * @return HasMany
     */

    public function publication(): HasMany {
        return $this->hasMany( Publication::class );
    }

    /**
     * @return HasMany
     */

    public function news(): HasMany {
        return $this->hasMany( News::class );
    }

    /**
     * @return HasMany
     */

    public function ads(): HasMany {
        return $this->hasMany( Ad::class );
    }

}
