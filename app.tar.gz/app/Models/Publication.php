<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * @property string $course
 * @property string $pdf
 * @property string $type
 * @property int $category_id
 */
class Publication extends Model
{
    protected $table='publications';
    protected $fillable=[
        'course',
        'pdf',
        'type',
        'category_id',
        ];


    /**
     * @return BelongsTo
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo( Category::class, 'category_id', 'id' );
    }
}
