@extends('layouts.master')
@section('main-content')
    <div class="col-md-12  mb-4">
        <div class="card text-left">

            <div class="card-body detail-page">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h4 class="card-title mb-2">Events Feedback Details</h4>
                    </div>
                    <div class="col-md-6">
                        <div class="dropdown">
                            <div class="user align-self-end text-right">
                                <a href="{{route('event_feedback')}}" class="btn btn-primary btn-rounded">Back</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="office-detail-row">
                    <li class="list-group-item width-50"><strong>Feedback</strong></li>
                    <li class="list-group-item width-50">{{$item->feedback}}</li>
                </div>
                <div class="office-detail-row">
                    <li class="list-group-item width-50"><strong>Event_Id</strong></li>
                    <li class="list-group-item width-50">{{$item->event_id ? $item->event->title_en : ''}}</li>
                </div>
                <div class="office-detail-row">
                    <li class="list-group-item width-50"><strong>User_Id</strong></li>
                    <li class="list-group-item width-50">{{$item->user_id ? $item->user->name : ''}}</li>
                </div>
                </ul>
            </div>
        </div>
    </div>

    </div>
    <!-- end of col -->
@endsection
