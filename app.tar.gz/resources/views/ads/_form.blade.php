@if(isset($item))
    {!! Form::open(['url' => route('ads-update', $item['id']), 'class'=> 'ajax', 'method' => 'post', 'id' => 'update-ads-form']) !!}
@else
    {!! Form::open(['url' => route('ads-store'), 'class'=> 'ajax', 'method' => 'post', 'id' => 'create-ads-form']) !!}
@endif
<div class="row">
    {{ csrf_field() }}
    <div class="col-md-6 form-group mb-3">
        <label for="title_en">Title EN <span class="required">*</span></label>
        {!! Form::text('title_en', $item->title_en ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'title_en']) !!}
        <div class="form-error title_en"></div>
    </div>
    <div class="col-md-6 form-group mb-3">
        <label for="title_sp">Title SP <span class="required">*</span></label>
        {!! Form::text('title_sp', $item->title_sp ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'title_sp']) !!}
        <div class="form-error title_sp"></div>
    </div>

    <div class="col-md-6 form-group mb-3">
        <label for="description_en">Description EN <span class="required">*</span></label>
        {!! Form::textarea('description_en', $item->description_en ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'description_en']) !!}
        <div class="form-error description_en"></div>
    </div>
    <div class="col-md-6 form-group mb-3">
        <label for="description_sp">Description SP <span class="required">*</span></label>
        {!! Form::textarea('description_sp', $item->description_sp ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'description_sp']) !!}
        <div class="form-error description_sp"></div>
    </div>
    <div class="col-md-6 form-group mb-3">
        <label for="phone">Phone <span class="required">*</span></label>
        {!! Form::text('phone', $item->phone ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'phone']) !!}
        <div class="form-error phone"></div>
    </div>
    <div class="col-md-6 form-group mb-3">
        <label for="email">Email <span class="required">*</span></label>
        {!! Form::text('email', $item->email ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'email']) !!}
        <div class="form-error email"></div>
    </div>
    <div class="col-md-6 form-group mb-3">
        <label for="logo" class="col-md-12">Image</label>
        {!! Form::file('image_url', ['class'=>'inputfile', 'id' => 'image_url',  'data-preview-file-type' => 'text']) !!}
        <label for="image_url" class="inputfilelabel"><strong>Choose a file</strong></label>
        <div class="form-error image_url"></div>
        <div id="target" class="mt-4">
            @if(isset($item))
                @if($item['image_url'])
                    <img class="office-logo rounded img-thumbnail" src="{{ asset('public/storage/'.$item->image_url) }}"
                         alt="">
                @endif
            @endif
        </div>
    </div>

    <div class="col-md-6 form-group mb-3">
        <label for="category_id">Category <span class="required">*</span></label>
        {!! Form::select('category_id', \App\Services\CategoryService::allWithIdAndName(), $item->category_id ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'category_id', 'placeholder' => 'Select Category']) !!}
        <div class="form-error category_id"></div>
    </div>
    <div class="col-md-12">
        {!! Form::hidden('old_image_url', $item->image_url ?? null) !!}
        <button type="submit" class="btn btn-primary submit">Save</button>
    </div>

</div>
{!! Form::close() !!}
<script type="text/javascript">
    // var input   = $('.inputfile')[0];
    let label = $('.inputfilelabel')[0];
    labelVal = label.innerHTML;

    $('input[type=file]').on('change', function (e) {
        let file = e.target.files[0];
        let filename = file.name;
        if (filename) {
            let reader = new FileReader();
            reader.onload = function (e2) {
                $('#target').html('<img class="office-logo rounded img-thumbnail" src="' + e2.target.result + '" alt="">');
            };
            reader.readAsDataURL(file);
            label.innerHTML = filename;
        } else {
            label.innerHTML = labelVal;
        }
    });
</script>
