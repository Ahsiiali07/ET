@extends('layouts.master')
@section('main-content')
    <div class="col-md-12  mb-4">
        <div class="card text-left">

            <div class="card-body detail-page">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h4 class="card-title mb-2">News Details</h4>
                    </div>
                    <div class="col-md-6">
                        <div class="dropdown">
                            <div class="user align-self-end text-right">
                                <a href="{{route('ads')}}" class="btn btn-primary btn-rounded">Back</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="office-detail-row">
                    <li class="list-group-item width-50"><strong>Title_en</strong></li>
                    <li class="list-group-item width-50">{{$item->title_en}}</li>
                </div>
                <div class="office-detail-row">
                    <li class="list-group-item width-50"><strong>Title_sp</strong></li>
                    <li class="list-group-item width-50">{{$item->title_sp}}</li>
                </div>
                <div class="office-detail-row">
                    <li class="list-group-item width-50"><strong>Phone</strong></li>
                    <li class="list-group-item width-50">{{$item->phone}}</li>
                </div>
                <div class="office-detail-row">
                    <li class="list-group-item width-50"><strong>Description_en</strong></li>
                    <li class="list-group-item width-50">{{$item->description_en}}</li>
                </div>
                <div class="office-detail-row">
                    <li class="list-group-item width-50"><strong>Description_sp</strong></li>
                    <li class="list-group-item width-50">{{$item->description_sp}}</li>
                </div>
                <div class="office-detail-row">
                    <li class="list-group-item width-50"><strong>Email</strong></li>
                    <li class="list-group-item width-50">{{$item->email}}</li>
                </div>


                <div class="office-detail-row">
                    <li class="list-group-item width-50"><strong>Image_url</strong></li>
                    <li class="list-group-item width-50"><img height="50" src="{{ asset('public/storage/'.$item->image_url ?? null) }}" class="rounded-circle m-0 avatar-sm-table"></li>
                </div>
                </ul>
            </div>
        </div>
    </div>

    </div>
    <!-- end of col -->
@endsection
