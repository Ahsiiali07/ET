@if(isset($item))
    {!! Form::open(['url' => route('events-update', $item['id']), 'class'=> 'ajax', 'method' => 'post', 'id' => 'update-events-form']) !!}
@else
    {!! Form::open(['url' => route('events-store'), 'class'=> 'ajax', 'method' => 'post', 'id' => 'create-events-form']) !!}
@endif
<div class="row">
    {{ csrf_field() }}
    <div class="col-md-6 form-group mb-3">
        <label for="name_en">Name EN <span class="required">*</span></label>
        {!! Form::text('name_en', $item->name_en ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'name_en']) !!}
        <div class="form-error name_en"></div>
    </div>
    <div class="col-md-6 form-group mb-3">
        <label for="name_sp">Name SP <span class="required">*</span></label>
        {!! Form::text('name_sp', $item->name_sp ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'name_sp']) !!}
        <div class="form-error name_sp"></div>
    </div>

    <div class="col-md-6 form-group mb-3">
        <label for="description_en">Description EN <span class="required">*</span></label>
        {!! Form::textarea('description_en', $item->description_en ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'description_en']) !!}
        <div class="form-error description_en"></div>
    </div>
    <div class="col-md-6 form-group mb-3">
        <label for="description_sp">Description SP <span class="required">*</span></label>
        {!! Form::textarea('description_sp', $item->description_sp ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'description_sp']) !!}
        <div class="form-error description_sp"></div>
    </div>
    <div class="col-md-6 form-group mb-3">
        <label for="location">Location <span class="required">*</span></label>
        {!! Form::text('location', $item->location ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'location']) !!}
        <div class="form-error location"></div>
    </div>
    <div class="col-md-6 form-group mb-3">
        <label for="category_id">Category <span class="required">*</span></label>
        {!! Form::select('category_id', \App\Services\EventCategoryService::allWithIdAndName(), $item->category_id ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'category_id', 'placeholder' => 'Select Category']) !!}
        <div class="form-error category_id"></div>
    </div>
    <div class="col-md-6 form-group mb-3">
        <label for="logo" class="col-md-12">Images</label>
        {!! Form::file('images[]', ['class'=>'inputfile', 'id' => 'images',  'data-preview-file-type' => 'text', 'multiple' => true]) !!}
        <label for="images" class="inputfilelabel"><strong>Choose a file</strong></label>
        <div class="form-error images"></div>
        <div id="target" class="mt-4">
            @if(isset($item))
                @if($item['images'])
                    <img class="office-logo rounded img-thumbnail" src="{{ asset('public/storage/'.$item->images) }}"
                         alt="">
                @endif
            @endif
        </div>
    </div>
    <div class="col-md-12">
        {!! Form::hidden('old_images', $item->images ?? null) !!}
        <button type="submit" class="btn btn-primary submit">Save</button>
    </div>

</div>
{!! Form::close() !!}
<script type="text/javascript">
    // var input   = $('.inputfile')[0];
    let label = $('.inputfilelabel')[0];
    labelVal = label.innerHTML;

    $('input[type=file]').on('change', function (e) {
        let file = e.target.files[0];
        let filename = file.name;
        if (filename) {
            let reader = new FileReader();
            reader.onload = function (e2) {
                $('#target').html('<img class="office-logo rounded img-thumbnail" src="' + e2.target.result + '" alt="">');
            };
            reader.readAsDataURL(file);
            label.innerHTML = filename;
        } else {
            label.innerHTML = labelVal;
        }
    });
</script>
