<?php

return [
    'Payment Account detail updated Successfully!' => 'Payment Account detail updated Successfully!',
    'Payment Account detail added Successfully!' => 'Payment Account detail added Successfully!',
    'No Post Found!' => 'No Post Found!',
    'No Recent Post Found!' => 'No Recent Post Found!',
    'Post deleted Successfully!' => 'Post deleted Successfully!',
];
