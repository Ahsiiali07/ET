<?php

return [
    'Post added Successfully!' => 'Post added Successfully!',
    'Post updated Successfully!' => 'Post updated Successfully!',
    'No Post Found!' => 'No Post Found!',
    'Post deleted Successfully!' => 'Post deleted Successfully!',
    'Post shared Successfully!' => 'Post shared Successfully!',
    'Post dislike Successfully!' => 'Post dislike Successfully!',
    'Post like Successfully!' => 'Post like Successfully!',
];
