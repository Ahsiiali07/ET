<?php

return [
    'Support Request Sent!' => 'Support Request Sent!',
];
