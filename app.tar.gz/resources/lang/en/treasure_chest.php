<?php

return [
    'No Treasure Chest Found!' => 'No Treasure Chest Found!',
];
