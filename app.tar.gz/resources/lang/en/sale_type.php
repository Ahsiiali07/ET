<?php

return [
    'No Sale Type Found!' => 'No Sale Type Found!',
];
