<?php

return [
    'Post Attachment deleted Successfully!' => 'Post Attachment deleted Successfully!',
    'Post Attachment not found!' => 'Post Attachment not found!',
];
