<?php

return [

    'Hello Support Manager'     => 'Hello Support Manager',
    'A new support request is generated, by one of our users.'     => 'A new support request is generated, by one of our users.',
    'Request was generated from'     => 'Request was generated from',
    'We have received your request for Password reset, the pin given below can be used to reset your password'     => 'We have received your request for Password reset, the pin given below can be used to reset your password',
    'If you have any questions, just contact us through the support.'     => 'If you have any questions, just contact us through the support.',
    'Regards' => 'Regards',
    'Team' => 'Team',
    'Dear' => 'Dear',
    'New OTP is generated' => 'New OTP is generated',
    'Thanks for joining' => 'Thanks for joining',
    'Below is the One time password, please use it in your app to complete your signup and email verification.' => 'Below is the One time password, please use it in your app to complete your signup and email verification.',
];
