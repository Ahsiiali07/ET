<?php

return [
    'No Notification Found!' => 'No Notification Found!',
    'Notifications sent successfully!' => 'Notifications sent successfully!',
    'Notifications not sent!' => 'Notifications not sent!',
];
