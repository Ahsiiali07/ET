<?php

return [
    'No Sale Type Found!' => 'Kein Verkaufstyp gefunden!',
];
