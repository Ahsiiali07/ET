<?php

return [
    'Post Attachment deleted Successfully!' => 'Post-Anhang erfolgreich gelöscht!.',
    'Post Attachment not found!' => 'Post-Anhang nicht gefunden!.',
];
