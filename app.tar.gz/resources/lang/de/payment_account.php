<?php

return [
    'Payment Account detail updated Successfully!' => 'Zahlungskontodetails erfolgreich aktualisiert!',
    'Payment Account detail added Successfully!' => 'Zahlungskontodetails erfolgreich hinzugefügt!',
    'No Post Found!' => 'Kein Beitrag gefunden!',
    'No Recent Post Found!' => 'Kein neuer Beitrag gefunden!',
    'Post deleted Successfully!' => 'Beitrag erfolgreich gelöscht!',
];
