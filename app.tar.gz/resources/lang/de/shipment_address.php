<?php

return [
    'Shipment address updated Successfully!' => 'Keine Kategorie gefunden!.',
    'Shipment address added Successfully!' => 'Versandadresse erfolgreich hinzugefügt!.',
    'No Shipment address Found!' => 'Keine Versandadresse gefunden!',
    'Shipment address deleted Successfully!' => 'Sendungsadresse erfolgreich gelöscht!',
];
