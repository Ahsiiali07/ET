<?php

return [

    'success'     => 'Erfolg',
    'Operation Successful!'     => 'Betrieb erfolgreich!.',
    'User Unauthorized!'        => 'Benutzer nicht autorisiert!.',
    'Parameters Invalid!'        => 'Parameter ungültig!.',
    'No Found!'        => 'Nicht gefunden!',
    'Item added successfully!'        => 'Artikel erfolgreich hinzugefügt!',
    'Item updated successfully!'        => 'Artikel erfolgreich aktualisiert!',
    'Wrong Credentials!'        => 'Falsche Anmeldeinformationen!',
    'Success response!'        => 'Erfolgsreaktion!',
    'Successfully Removed!'        => 'Erfolgreich entfernt!',

];
