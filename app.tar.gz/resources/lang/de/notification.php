<?php

return [
    'No Notification Found!' => 'Keine Benachrichtigung gefunden!.',
    'Notifications sent successfully!' => 'Benachrichtigungen erfolgreich gesendet!.',
    'Notifications not sent!' => 'Benachrichtigungen nicht gesendet!.',
];
