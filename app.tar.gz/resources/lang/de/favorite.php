<?php

return [
    'Product removed from favorites successfully!' => 'Produkt erfolgreich aus Favoriten entfernt!',
    'Error: product not removed from favorites!' => 'Fehler: Produkt nicht aus Favoriten entfernt!',
    'Product added to favorites successfully!' => 'Produkt erfolgreich zu Favoriten hinzugefügt!',
    'Error: product not added from favorites!' => 'Fehler: Produkt nicht aus Favoriten hinzugefügt!',
    'No Items Found!' => 'Keine Elemente gefunden!',
];
