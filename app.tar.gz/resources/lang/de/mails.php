<?php

return [

    'Hello Support Manager'     => 'Hallo Support Manager',
    'A new support request is generated, by one of our users.'     => 'Eine neue Supportanfrage wird von einem unserer Benutzer generiert.',
    'Request was generated from'     => 'Anfrage wurde generiert von',
    'We have received your request for Password reset, the pin given below can be used to reset your password'     => 'Wir haben Ihre Anfrage zum Zurücksetzen des Passworts erhalten. Die unten angegebene PIN kann zum Zurücksetzen Ihres Passworts verwendet werden',
    'If you have any questions, just contact us through the support.'     => 'Wenn Sie Fragen haben, kontaktieren Sie uns einfach über den Support.',
    'Regards' => 'Grüße',
    'Team' => 'Mannschaft',
    'Dear' => 'sehr geehrter',
    'New OTP is generated' => 'Neues OTP wird generiert',
    'Thanks for joining' => 'Danke fürs Beitreten',
    'Below is the One time password, please use it in your app to complete your signup and email verification.' => 'Unten finden Sie das Einmalpasswort. Verwenden Sie es in Ihrer App, um Ihre Anmeldung und E-Mail-Bestätigung abzuschließen.',
];
