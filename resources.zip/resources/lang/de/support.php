<?php

return [
    'Support Request Sent!' => 'Supportanfrage gesendet!',
];
