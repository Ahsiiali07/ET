<?php

return [
    'No Category Found!' => 'Keine Kategorie gefunden!.',
    'No Products Found!' => 'Keine Produkte gefunden!.',
];
