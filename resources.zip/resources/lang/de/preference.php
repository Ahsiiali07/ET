<?php

return [
    'Preference updated Successfully!' => 'Einstellung erfolgreich aktualisiert!.',
];
