<?php

return [
    'Post added Successfully!' => 'Beitrag erfolgreich hinzugefügt!.',
    'Post updated Successfully!' => 'Beitrag erfolgreich aktualisiert!.',
    'No Post Found!' => 'Kein Beitrag gefunden!',
    'Post deleted Successfully!' => 'Beitrag erfolgreich gelöscht!',
    'Post shared Successfully!' => 'Beitrag erfolgreich geteilt!',
    'Post dislike Successfully!' => 'Post Abneigung erfolgreich!',
    'Post like Successfully!' => 'Poste gerne erfolgreich!',
];
