<?php

return [
    'Post Comment added Successfully!' => 'Post Comment added Successfully!',
    'Post Comment updated Successfully!' => 'Post Comment updated Successfully!',
    'No Post Comments Found!' => 'No Post Comments Found!',
];
