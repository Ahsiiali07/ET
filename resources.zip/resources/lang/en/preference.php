<?php

return [
    'Preference updated Successfully!' => 'Preference updated Successfully!',
];
