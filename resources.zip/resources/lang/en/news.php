<?php

return [
    'No News Found!' => 'No News Found!',
];
