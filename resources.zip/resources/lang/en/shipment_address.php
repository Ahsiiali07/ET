<?php

return [
    'Shipment address updated Successfully!' => 'Shipment address updated Successfully!',
    'Shipment address added Successfully!' => 'Shipment address added Successfully!',
    'No Shipment address Found!' => 'No Shipment address Found!',
    'Shipment address deleted Successfully!' => 'Shipment address deleted Successfully!',
];
