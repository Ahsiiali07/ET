<?php

return [
    'Product removed from favorites successfully!' => 'Product removed from favorites successfully!',
    'Error: product not removed from favorites!' => 'Error: product not removed from favorites!',
    'Product added to favorites successfully!' => 'Product added to favorites successfully!',
    'Error: product not added from favorites!' => 'Error: product not added from favorites!',
    'No Items Found!' => 'No Items Found!',
];
