<?php

return [
    'No Rating Found!' => 'No Rating Found!',
    'Rating updated Successfully!' => 'Rating updated Successfully!',
    'Rated Successfully!' => 'Rated Successfully!',
];
