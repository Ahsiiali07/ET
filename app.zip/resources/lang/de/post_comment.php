<?php

return [
    'Post Comment added Successfully!' => 'Beitrag Kommentar erfolgreich hinzugefügt!.',
    'Post Comment updated Successfully!' => 'Beitrag Kommentar erfolgreich aktualisiert!.',
    'No Post Comments Found!' => 'Keine Post Kommentare gefunden!.',
];
