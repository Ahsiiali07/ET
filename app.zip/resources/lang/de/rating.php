<?php

return [
    'No Rating Found!' => 'Keine Bewertung gefunden!',
    'Rating updated Successfully!' => 'Bewertung erfolgreich aktualisiert!',
    'Rated Successfully!' => 'Erfolgreich bewertet!',
];
