<?php

return [
    'No Treasure Chest Found!' => 'Keine Schatzkiste gefunden!',
];
