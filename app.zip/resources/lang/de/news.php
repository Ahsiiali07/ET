<?php

return [
    'No News Found!' => 'Keine Nachrichten gefunden!.',
];
