@extends('layouts.master')
@section('main-content')
    <div class="col-md-12  mb-4">
        <div class="card text-left">

            <div class="card-body detail-page">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h4 class="card-title mb-2">Publications Details</h4>
                    </div>
                    <div class="col-md-6">
                        <div class="dropdown">
                            <div class="user align-self-end text-right">
                                <a href="{{route('publications')}}" class="btn btn-primary btn-rounded">Back</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="office-detail-row">
                    <li class="list-group-item width-50"><strong>Course</strong></li>
                    <li class="list-group-item width-50">{{$item->course}}</li>
                </div>
                <div class="office-detail-row">
                    <li class="list-group-item width-50"><strong>Type</strong></li>
                    <li class="list-group-item width-50">{{$item->type}}</li>
                </div>

                <div class="office-detail-row">
                    <li class="list-group-item width-50"><strong>Category</strong></li>
                    <li class="list-group-item width-50">{{$item->category_id}}</li>
                </div>

                <div class="office-detail-row">
                    <li class="list-group-item width-50"><strong>PDF</strong></li>
                    <li class="list-group-item width-50"><img height="50" src="{{ asset('public/storage/'.$item->pdf ?? null) }}" class="rounded-circle m-0 avatar-sm-table"></li>
                </div>
                </ul>
            </div>
        </div>
    </div>

    </div>
    <!-- end of col -->
@endsection
