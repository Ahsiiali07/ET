@if(isset($item))
    {!! Form::open(['url' => route('publications-update', $item['id']), 'class'=> 'ajax', 'method' => 'post', 'id' => 'update-publications-form']) !!}
@else
    {!! Form::open(['url' => route('publications-store'), 'class'=> 'ajax', 'method' => 'post', 'id' => 'create-publications-form']) !!}
@endif
<div class="row">
    {{ csrf_field() }}
    <div class="col-md-6 form-group mb-3">
        <label for="course">Course <span class="required">*</span></label>
        {!! Form::text('course', $item->course ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'course']) !!}
        <div class="form-error course"></div>
    </div>


    <div class="col-md-6 form-group mb-3">
        <label for="category_id">Category <span class="required">*</span></label>
        {!! Form::select('category_id', \App\Services\CategoryService::allWithIdAndName(), $item->category_id ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'category_id', 'placeholder' => 'Select Category']) !!}
        <div class="form-error category_id"></div>
    </div>
    <div class="col-md-6 form-group mb-3">
        <label for="type">Type <span class="required">*</span></label>
        {!! Form::text('type', $item->type ?? '', ['class'=>'form-control form-control-rounded', 'id' => 'type']) !!}
        <div class="form-error type"></div>
    </div>
    <div class="col-md-6 form-group mb-3">
        <label for="logo" class="col-md-12">pdf</label>
        {!! Form::file('pdf', ['class'=>'inputfile', 'id' => 'pdf',  'data-preview-file-type' => 'text']) !!}
        <label for="pdf" class="inputfilelabel"><strong>Choose a file</strong></label>
        <div class="form-error pdf"></div>
        <div id="target" class="mt-4">
            @if(isset($item))
                @if($item['pdf'])
                    <img class="office-logo rounded img-thumbnail" src="{{ asset('public/storage/'.$item->pdf) }}"
                         alt="">
                @endif
            @endif
        </div>
    </div>
    <div class="col-md-12">
        {!! Form::hidden('old_pdf', $item->pdf ?? null) !!}
        <button type="submit" class="btn btn-primary submit">Save</button>
    </div>

</div>
{!! Form::close() !!}
<script type="text/javascript">
    // var input   = $('.inputfile')[0];
    let label = $('.inputfilelabel')[0];
    labelVal = label.innerHTML;

    $('input[type=file]').on('change', function (e) {
        let file = e.target.files[0];
        let filename = file.name;
        if (filename) {
            let reader = new FileReader();
            reader.onload = function (e2) {
                $('#target').html('<img class="office-logo rounded img-thumbnail" src="' + e2.target.result + '" alt="">');
            };
            reader.readAsDataURL(file);
            label.innerHTML = filename;
        } else {
            label.innerHTML = labelVal;
        }
    });
</script>
