<div class="ajax-listing">
    <div class="table-responsive">
        <table class="display table table-striped table-bordered" style="width:100%">
            <thead>
            <tr>
                <th class="text-center">Title EN</th>
                <th class="text-center">Title SP</th>
                <th class="text-center">Phone</th>
                <th class="text-center">Description EN</th>
                <th class="text-center">Description SP</th>
                <th class="text-center">Email</th>
                <th class="text-center">Image</th>
                <th class="text-center">Category</th>
                <th class="text-center">Created At</th>
                <th class="text-center" style="min-width: 90px">Action</th>
            </tr>
            </thead>
            <tbody>
            @if($items->count())
                @foreach($items as $item)
                    <tr>
                        <td>{{$item['title_en']}}</td>
                        <td>{{$item['title_sp']}}</td>
                        <td>{{$item['phone']}}</td>
                        <td>{{$item['description_en']}}</td>
                        <td>{{$item['description_sp']}}</td>
                        <td>{{$item['email']}}</td>
                        <td class="text-center"><img height="50" src="{{ asset('public/storage/'.$item->image_url ?? null) }}" class="rounded-circle m-0 avatar-sm-table"></td>
                        <td>{{$item['category_id']}}</td>
                        <td class="text-center">{{ $item['created_at'] }}</td>
                        <td class="text-center">
                            <a href="{{route('ad-show',$item->id)}}" class="text-success">
                                <i class="nav-icon i-Eye1 font-weight-bold"></i>
                            </a>
                            <a href="{{route('ads-edit',$item->id)}}" class="text-success">
                                <i class="nav-icon i-Pen-2 font-weight-bold"></i>
                            </a>
                            <form id="delete-form-{{$item->id}}" method="post" class="delete-form"
                                  action="{{route('ads-delete',$item->id)}}">
                                {{csrf_field()}}
                                <input type="hidden" name="_method" value="DELETE">
                                <button class="text-danger submit p-0" type="submit">
                                    <i class="nav-icon i-Close-Window font-weight-bold"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            @else
                <tr>
                    <td colspan="9" align="center">
                        <strong class="red-text">Record not found</strong>
                    </td>
                </tr>
            @endif

            </tbody>
        </table>
    </div>
    <div class="pagination-container">
        {{ $items->links() }}
    </div>
</div>
