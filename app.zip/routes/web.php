<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get( '/', 'WelcomeController@index' )->name( 'welcome' );

Auth::routes();

Route::get( '/home', 'HomeController@index' )->name( 'home' );

Route::prefix( 'users' )->group( static function () {
    Route::get( '/', 'Web\UserController@index' )->name( 'users' );
    Route::get( '/patient', 'Web\UserController@indexPatient' )->name( 'users-patient' );
    Route::get( '/psw', 'Web\UserController@indexPSW' )->name( 'users-psw' );
    Route::get('export/', 'Web\UserController@export')->name('user-export');
    Route::get( '/{id}', 'Web\UserController@show' )->name( 'user' );
    Route::get( '/{id}/edit', 'Web\UserController@edit' )->name( 'user-edit' );
    Route::post( '/{id}/update', 'Web\UserController@update' )->name( 'user-status-update' );
    Route::delete( '/{id}/delete', 'Web\UserController@destroy' )->name( 'user-delete' );
    Route::post( '/{id}/approve', 'Web\UserController@approve' )->name( 'user-approve' );
    Route::get( '/{id}/show-answers', 'Web\QuestionController@showAnswersForSpecificUser' )->name( 'user-answers' );
    Route::get( '/{id}/show-documents', 'Web\QuestionController@showDocumentsForSpecificUser' )->name( 'user-documents' );
} );

//Route::prefix( 'services' )->group( static function () {
//    Route::get( '/', 'Web\ServiceController@index' )->name( 'services' );
//    Route::get( '/create', 'Web\ServiceController@create' )->name( 'service-create' );
//    Route::post( '/store', 'Web\ServiceController@store' )->name( 'service-store' );
//    Route::get( '/{id}', 'Web\ServiceController@show' )->name( 'service' );
//    Route::delete( '/{id}', 'Web\ServiceController@destroy' )->name( 'service-delete' );
//    Route::get( '/{id}/edit', 'Web\ServiceController@edit' )->name( 'service-edit' );
//    Route::post( '/{id}/update', 'Web\ServiceController@update' )->name( 'service-update' );
//} );

Route::prefix( 'categories' )->group( static function () {
    Route::get( '/', 'Web\CategoryController@index' )->name( 'categories' );
    Route::get( '/create', 'Web\CategoryController@create' )->name( 'category-create' );
    Route::post( '/store', 'Web\CategoryController@store' )->name( 'category-store' );
    Route::get( '/{id}', 'Web\CategoryController@show' )->name( 'category' );
    Route::delete( '/{id}', 'Web\CategoryController@destroy' )->name( 'category-delete' );
    Route::get( '/{id}/edit', 'Web\CategoryController@edit' )->name( 'category-edit' );
    Route::post( '/{id}/update', 'Web\CategoryController@update' )->name( 'category-update' );
} );
Route::prefix('event-categories')->group( static function() {
    Route::get('/','Web\EventCategoryController@index')->name('event-categories');
    Route::get( '/create', 'Web\EventCategoryController@create' )->name( 'event-categories-create' );
    Route::post( '/store', 'Web\EventCategoryController@store' )->name( 'event-categories-store' );
    Route::get( '/{id}', 'Web\EventCategoryController@show' )->name( 'event-categories-show' );
    Route::get( '/{id}/edit', 'Web\EventCategoryController@edit' )->name( 'event-categories-edit' );
    Route::post( '/{id}/update', 'Web\EventCategoryController@update' )->name( 'event-categories-update' );
    Route::delete( '/{id}', 'Web\EventCategoryController@destroy' )->name( 'event-categories-delete' );
});

Route::prefix( 'content-management' )->group( static function () {
    Route::get( '/', 'Web\ContentManagementController@index' )->name( 'cms' );
    Route::get( '/{id}', 'Web\ContentManagementController@show' )->name( 'cm' );
    Route::delete( '/{id}', 'Web\ContentManagementController@destroy' )->name( 'cm-delete' );
    Route::get( '/{id}/edit', 'Web\ContentManagementController@edit' )->name( 'cm-edit' );
    Route::post( '/{id}/update', 'Web\ContentManagementController@update' )->name( 'cm-update' );
} );

Route::prefix( 'support' )->group( static function () {
    Route::get( '/', 'Web\SupportController@index' )->name( 'support-requests' );
    Route::get( '/{id}', 'Web\SupportController@show' )->name( 'support-request' );
    Route::post( '/{id}/close', 'Web\SupportController@close' )->name( 'support-close' );
    Route::post( '/{id}/open', 'Web\SupportController@open' )->name( 'support-open' );
});

Route::prefix('news')->group( static function() {
   Route::get('/','Web\NewsController@index')->name('news');
   Route::get( '/create', 'Web\NewsController@create' )->name( 'news-create' );
    Route::post( '/store', 'Web\NewsController@store' )->name( 'news-store' );
    Route::get( '/{id}', 'Web\NewsController@show' )->name( 'new-show' );
    Route::get( '/{id}/edit', 'Web\NewsController@edit' )->name( 'news-edit' );
    Route::post( '/{id}/update', 'Web\NewsController@update' )->name( 'news-update' );
    Route::delete( '/{id}', 'Web\NewsController@destroy' )->name( 'news-delete' );
});

Route::prefix('shops')->group( static function() {
    Route::get('/','Web\ShopController@index')->name('shops');
    Route::get( '/create', 'Web\ShopController@create' )->name( 'shops-create' );
    Route::post( '/store', 'Web\ShopController@store' )->name( 'shops-store' );
    Route::get( '/{id}', 'Web\ShopController@show' )->name( 'shop-show' );
    Route::get( '/{id}/edit', 'Web\ShopController@edit' )->name( 'shops-edit' );
    Route::post( '/{id}/update', 'Web\ShopController@update' )->name( 'shops-update' );
    Route::delete( '/{id}', 'Web\ShopController@destroy' )->name( 'shops-delete' );
});

Route::prefix('circulars')->group( static function() {
    Route::get('/','Web\CircularController@index')->name('circulars');
    Route::get( '/create', 'Web\CircularController@create' )->name( 'circulars-create' );
    Route::post( '/store', 'Web\CircularController@store' )->name( 'circulars-store' );
    Route::get( '/{id}', 'Web\CircularController@show' )->name( 'circular-show' );
    Route::get( '/{id}/edit', 'Web\CircularController@edit' )->name( 'circulars-edit' );
    Route::post( '/{id}/update', 'Web\CircularController@update' )->name( 'circulars-update' );
    Route::delete( '/{id}', 'Web\CircularController@destroy' )->name( 'circulars-delete' );
});

Route::prefix('events')->group( static function() {
    Route::get('/','Web\EventController@index')->name('events');
    Route::get( '/create', 'Web\EventController@create' )->name( 'events-create' );
    Route::post( '/store', 'Web\EventController@store' )->name( 'events-store' );
    Route::get( '/{id}', 'Web\EventController@show' )->name( 'events-show' );
    Route::get( '/{id}/edit', 'Web\EventController@edit' )->name( 'events-edit' );
    Route::post( '/{id}/update', 'Web\EventController@update' )->name( 'events-update' );
    Route::delete( '/{id}', 'Web\EventController@destroy' )->name( 'events-delete' );
});

Route::prefix('publications')->group( static function() {
    Route::get('/','Web\PublicationController@index')->name('publications');
    Route::get( '/create', 'Web\PublicationController@create' )->name( 'publications-create' );
    Route::post( '/store', 'Web\PublicationController@store' )->name( 'publications-store' );
    Route::get( '/{id}', 'Web\PublicationController@show' )->name( 'publication-show' );
    Route::get( '/{id}/edit', 'Web\PublicationController@edit' )->name( 'publications-edit' );
    Route::post( '/{id}/update', 'Web\PublicationController@update' )->name( 'publications-update' );
    Route::delete( '/{id}', 'Web\PublicationController@destroy' )->name( 'publications-delete' );
});

Route::prefix('event_feedback')->group( static function() {
    Route::get('/','Web\EventFeedbackController@index')->name('event_feedback');
    Route::get( '/{id}', 'Web\EventFeedbackController@show' )->name( 'event_feedback-show' );
    Route::delete( '/{id}', 'Web\EventFeedbackController@destroy' )->name( 'event_feedback-delete' );
});

Route::prefix('ads')->group( static function() {
    Route::get('/','Web\AdController@index')->name('ads');
    Route::get( '/create', 'Web\AdController@create' )->name( 'ads-create' );
    Route::post( '/store', 'Web\AdController@store' )->name( 'ads-store' );
    Route::get( '/{id}', 'Web\AdController@show' )->name( 'ad-show' );
    Route::get( '/{id}/edit', 'Web\AdController@edit' )->name( 'ads-edit' );
    Route::post( '/{id}/update', 'Web\AdController@update' )->name( 'ads-update' );
    Route::delete( '/{id}', 'Web\AdController@destroy' )->name( 'ads-delete' );
});




//
//Route::prefix( 'notifications' )->group( static function () {
//    Route::get('/create', 'Web\NotificationController@create')->name('notification-create');
//    Route::post('/send-to-all', 'Web\NotificationController@sendNotificationToAll')->name('notification-send-to-all');
//} );

//Route::get( '/download/{filename}', 'GeneralController@download')->name('download');
