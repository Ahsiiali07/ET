<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property string $image_url
 * @property string $is_new
 * @property string $company_name
 */
class Circular extends Model
{
    protected $table='circulars';
    protected $fillable=[
        'image_url',
        'is_new',
        'company_name',
    ];
}
