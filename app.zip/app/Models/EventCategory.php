<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * @property string $name_en
 * @property string $name_sp
 * @property string $image_url
 */
class EventCategory extends Model
{
    protected $table='event_categories';

    protected $fillable=[
        'name_en',
        'name_sp',
        'image_url',
    ];


    /**
     * @return HasMany
     */
    public function events(): HasMany
    {
        return $this->hasMany(Event::class);
    }

}
