<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * @property string $title
 * @property string $phone
 * @property string $description
 * @property string $email
 * @property string $image_url
 * @property int $category_id
 * @property int $user_id
 * @property int $status
 *
 */
class Ad extends Model
{
    protected $table = 'ads';

    /** @var string[]  */
    protected $appends = [
        'is_mine',
    ];

    protected $fillable = [
        'title',
        'phone',
        'description',
        'email',
        'image_url',
        'category_id',
        'user_id',
        'status',
    ];

    /**
     * @return BelongsTo
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'category_id', 'id');
    }

    /**
     * @return BelongsTo
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    /**
     * @return boolean
     */
    public function getIsMineAttribute() {
        if(auth()->id()) {
            return ($this->attributes['user_id'] == auth()->id() );
        }

        return false;
    }
}
