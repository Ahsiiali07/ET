<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * @property string $name_en
 * @property string $name_sp
 * @property string $description_en
 * @property string $description_sp
 * @property string $author_en
 * @property string $author_sp
 * @property int $category_id
 */
class News extends Model
{
    protected $table='news';

    /** @var string[]  */
    protected $appends = [
        'time', 'date',
    ];

    protected $fillable = [
        'name_en',
        'name_sp',
        'description_en',
        'description_sp',
        'author_en',
        'author_sp',
        'category_id',

    ];

    /**
     * @return BelongsTo
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo( Category::class, 'category_id', 'id' );
    }

    /**
     * @return HasMany
     */
    public function images(): HasMany
    {
        return $this->hasMany(NewsImage::class);

    }

    /**
     * @return boolean
     */
    public function getDateAttribute() {
        $timestamp = (strtotime($this->created_at));
        return date('Y-m-d', $timestamp);
    }

    /**
     * @return boolean
     */
    public function getTimeAttribute() {
        $timestamp = (strtotime($this->created_at));
        return date('H:i:s', $timestamp);
    }

}