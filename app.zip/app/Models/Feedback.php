<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property string $email
 * @property string $title_en
 * @property string $title_sp
 * @property string $description_en
 * @property string $description_sp
 */
class Feedback extends Model
{
    protected $table='feedback';
    protected $fillable=[
       'email',
       'title_en',
       'title_sp',
       'description_en',
       'description_sp',
    ];
}
