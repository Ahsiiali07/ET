<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
/**
 * @property integer $user_id
 * @property integer $event_id
 * @property string $feedback
 */
class EventFeedback extends Model
{
    protected $table='events_feedback';
    protected $fillable=[
        'feedback',
        'event_id',
        'user_id'
    ];
    /**
     * @var mixed
     */



    /**
     * @return BelongsTo
     */
    public function event(): BelongsTo
    {
        return $this->belongsTo(Event ::class, 'event_id', 'id' );
    }

    /**
     * @return BelongsTo
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo( User::class );
    }
}
