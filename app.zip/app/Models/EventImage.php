<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * @property string $url
 * @property int $event_id
 */
class EventImage extends Model
{
    protected $table='event_images';
    protected $fillable=[
      'url',
      'event_id',
    ];

    /**
     * @return BelongsTo
     */
    public function event(): BelongsTo
    {
        return $this->belongsTo( Event::class, 'event_id', 'id' );
    }
}
