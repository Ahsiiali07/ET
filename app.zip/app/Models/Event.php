<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Event extends Model
{
    protected $table = 'events';

    /** @var string[]  */
    protected $appends = [
        'is_favorite',
    ];


    protected $fillable = [
        'name_en',
        'name_sp',
        'description_en',
        'description_sp',
        'location',
        'category_id',
    ];

    /**
     * @return BelongsTo
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo( EventCategory::class, 'category_id', 'id' );
    }

    /**
     * @return HasMany
     */

    public function images(): HasMany
    {
        return $this->hasMany(EventImage::class);

    }

    /**
     * @return HasMany
     */
    public function favorites(): HasMany
    {
        return $this->hasMany( Favorite::class );
    }

    /**
     * @return HasMany
     */
    public function favorite(): ?HasMany
    {
        if(auth()->id()){
            return $this->hasMany( Favorite::class )->where('user_id', auth()->id());
        }

        return null;
    }

    /**
     * @return HasMany
     */
    public function feedbacks(): HasMany
    {
        return $this->hasMany( EventFeedback::class );
    }

    /**
     * @return HasMany
     */
    public function myFeedbacks(): ?HasMany
    {
        if(auth()->id()){
            return $this->hasMany( EventFeedback::class )->where('user_id', auth()->id());
        }

        return null;
    }

    /**
     * @return boolean
     */
    public function getIsFavoriteAttribute() {
        if(auth()->id()) {
            return (bool) $this->favorite()->first();
        }

        return false;
    }

    /**
     * @return HasMany
     */
    public function eventfeedback(): ?HasMany
    {
        if(auth()->id()){
            return $this->hasMany( EventFeedback::class )->where('user_id', auth()->id());
        }

        return null;
    }
}
