<?php

namespace App\Services;

use App\Forms\IForm;
use App\Helpers\GeneralHelper;
use App\Models\Event;
use App\Models\EventImage;
use Illuminate\Validation\ValidationException;

class EventService extends BaseService {
    /**
     * EventService constructor. Disabled="disabled"
     */
    public function __construct() {
        $this->model = new Event();

        parent::__construct();

        $this->relations = [
            'category',
            'images',
            'feedbacks',
//            'myFeedbacks',
        ];
    }

    /** @var $model */
    public $model;

    /**
     * @param $images
     * @param $eventId
     */
    public function uploadImages( $images, $eventId ) {
        if ( count( $images ) > 0 ) {
            foreach ( $images as $key => $image ) {
                $item           = new EventImage();
                $item->url      = GeneralHelper::uploadImageManual( $image, 'images/events' );
                $item->event_id = $eventId;
                $item->save();
                sleep( 1 );
            }
        }
    }

    /**
     * @param $item
     *
     * @return mixed
     */
    public function getRelated( $item ) {
        $categoryId = $item->category->id;

        return Event::where( 'category_id', $categoryId )->where( 'id', '!=', $item['id'] )->with( $this->relations )->orderBy( 'id', 'DESC' )->limit( 5 )->get();
    }

}
