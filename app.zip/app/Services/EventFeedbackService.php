<?php

namespace App\Services;

use App\Models\EventFeedback;
use http\Env\Request;

class EventFeedbackService extends BaseService
{
    /* @var $feedback */
    public $feedback;

    /**
     * EventFeedbackService constructor.
     */
    public function __construct()
    {
        $this->model = new EventFeedback();

        parent::__construct();
    }


    /**
     * @param $userId
     *
     * @return mixed
     */
    public function getAllForUser($userId)
    {
        return $this->find([
            'user_id' => $userId
        ]);
    }

    /**
     * @param $userId
     * @param $event_id
     * @param $feedback
     * @return bool
     */
    public function addFeedback( $userId, $event_id, $feedback): bool
    {
        $item = new EventFeedback();
        $item->event_id = $event_id;
        $item->feedback = $feedback;
        $item->user_id  = $userId;
        return $item->save();
    }


}
