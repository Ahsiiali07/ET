<?php

namespace App\Services;

use App\Models\Circular;

class CircularService extends BaseService
{
    /**
     * CircularService constructor.
     */
    public function __construct()
    {
        $this->model= new Circular();
        parent::__construct();
    }

    /** @var $model */
    public $model;
}
