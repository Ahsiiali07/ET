<?php

namespace App\Services;

use App\Forms\IForm;
use App\Helpers\GeneralHelper;
use App\Models\Publication;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Validation\ValidationException;

class PublicationService extends BaseService
{
    /**
     * PublicationService constructor.
     */
   public function __construct()
   {
       $this->model= new Publication();
       parent::__construct();
       $this->relations = [
           'category',
       ];
   }
   /** @var $model */
    public $model;

    /**
     * @param IForm $form
     *
     * @return mixed
     * @throws ValidationException
     */
    public function store( IForm $form ) {
        // Validate Form
        $form->validate();

        $model = $this->model;

        // Assign values to model attributes
        $form->loadToModel( $model );
        if ( isset( $form->file ) ) {
            $model->file = GeneralHelper::uploadFile( $form->file, 'files' );
        }

        $model->save();

        return $model;
    }

    /**
     * @param $item
     *
     * @return mixed
     */
    public function getRelated( $item ) {
        $categoryId = $item->category->id;

        return Publication::where( 'category_id', $categoryId )->where( 'id', '!=', $item['id'] )->with( $this->relations )->orderBy( 'id', 'DESC' )->limit( 5 )->get();
    }

    /**
     * @param $categoryId
     * @param null $paginate
     *
     * @return LengthAwarePaginator|Builder[]|Collection
     */
    public function getByCategory( $categoryId, $paginate = null ) {
        if ( $paginate ) {
            if ( $this->relations ) {
                return $this->model->where('category_id', $categoryId)->with( $this->relations )->orderBy( 'id', 'DESC' )->paginate( $paginate );
            }

            return $this->model->where('category_id', $categoryId)->orderBy( 'id', 'DESC' )->paginate( $paginate );
        }

        if ( $this->relations ) {
            return $this->model->where('category_id', $categoryId)->with( $this->relations )->orderBy( 'id', 'DESC' )->get();
        }

        return $this->model->where('category_id', $categoryId)->orderBy( 'id', 'DESC' )->get();
    }
}
