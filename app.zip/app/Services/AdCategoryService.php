<?php

namespace App\Services;

use App\Models\AdCategory;

class AdCategoryService extends BaseService
{
    /**
     * AdCategoryService constructor.
     */
    public function __construct()
    {
        $this->model = new AdCategory();
        parent::__construct();
    }

    /** @var $model */
    public $model;
}
