<?php

namespace App\Services;

use App\Models\Ad;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;

class AdService extends BaseService
{
    /**
     * AdService constructor.
     */
    public function __construct()
    {
        $this->model = new Ad();
        parent::__construct();
    }

    /** @var $model */
    public $model;


    /**
     * @param $categoryId
     * @param null $paginate
     *
     * @return LengthAwarePaginator|Builder[]|Collection
     */
    public function getByCategory( $categoryId, $paginate = null ) {
        if ( $paginate ) {
            if ( $this->relations ) {
                return $this->model->where('category_id', $categoryId)->with( $this->relations )->orderBy( 'id', 'DESC' )->paginate( $paginate );
            }

            return $this->model->where('category_id', $categoryId)->orderBy( 'id', 'DESC' )->paginate( $paginate );
        }

        if ( $this->relations ) {
            return $this->model->where('category_id', $categoryId)->with( $this->relations )->orderBy( 'id', 'DESC' )->get();
        }

        return $this->model->where('category_id', $categoryId)->orderBy( 'id', 'DESC' )->get();
    }
}
