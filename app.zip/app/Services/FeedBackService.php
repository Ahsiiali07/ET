<?php

namespace App\Services;

use App\Models\Feedback;

class FeedBackService extends BaseService
{
    /**
   * FeedBackService constructor.
   */
    public function __construct()
    {
        $this->model = new Feedback();
        parent::__construct();
    }

    /** @var $model */
    public $model;

}
