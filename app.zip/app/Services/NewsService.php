<?php

namespace App\Services;

use App\Forms\IForm;
use App\Helpers\GeneralHelper;
use App\Models\News;
use App\Models\NewsImage;
use App\Models\Question;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Contracts\View\Factory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class NewsService extends BaseService
{
    /**
     * NewsService constructor.
     */
    public function __construct()
    {
        $this->model = new News();
        parent::__construct();
        $this->relations = [
            'category',
            'images'
        ];
    }

    /** @var $model */
    public $model;

    /**
     * @param $images
     * @param $newsId
     */
    public function uploadImages( $images, $newsId ) {
        if ( count( $images ) > 0 ) {
            foreach ( $images as $key => $image ) {
                $item           = new NewsImage();
                $item->url = GeneralHelper::uploadImageManual( $image, 'images/posts' );
                $item->news_id  = $newsId;
                $item->save();
                sleep( 1 );
            }
        }
    }

    /**
     * @param array $data
     * @param $paginate
     *
     * @return mixed
     */
    public function filter( array $data, $paginate = null  ) {
        $query = $this->model;
        if ( isset( $data['name_en'] ) ) {
            $query = $query->where( 'name_en', 'LIKE', '%' . $data['name_en'] . '%' );
        }
        if ( isset( $data['name_sp'] ) ) {
            $query = $query->where( 'name_sp', 'LIKE','%' .$data['name_sp'].'%' );
        }
        if ( isset( $data['description_en'] ) ) {
            $query = $query->where( 'description_en', $data['description_en'] );
        }
        if ( isset( $data['description_sp'] ) ) {
            $query = $query->where( 'description_sp', $data['description_sp'] );
        }
        if ( isset( $data['author_en'] ) ) {
            $query = $query->where( 'author_en', $data['author_en'] );
        }
        if ( isset( $data['author_sp'] ) ) {
            $query = $query->where( 'author_sp', $data['author_sp'] );
        }
        if ( isset( $data['category_id'] ) ) {
            $query = $query->where( 'category_id', $data['category_id'] );
        }
        if ( $paginate ) {
            return $query->orderBy('id', 'DESC')->paginate( $paginate );
        }

        return $query->orderBy('id', 'DESC')->get();
    }

    /**
     * @param $item
     *
     * @return mixed
     */
    public function getRelated( $item ) {
        $categoryId = $item->category->id;

        return News::where( 'category_id', $categoryId )->where( 'id', '!=', $item['id'] )->with( $this->relations )->orderBy( 'id', 'DESC' )->limit( 5 )->get();
    }

    /**
     * @param $categoryId
     * @param null $paginate
     *
     * @return LengthAwarePaginator|Builder[]|Collection
     */
    public function getByCategory( $categoryId, $paginate = null ) {
        if ( $paginate ) {
            if ( $this->relations ) {
                return $this->model->where('category_id', $categoryId)->with( $this->relations )->orderBy( 'id', 'DESC' )->paginate( $paginate );
            }

            return $this->model->where('category_id', $categoryId)->orderBy( 'id', 'DESC' )->paginate( $paginate );
        }

        if ( $this->relations ) {
            return $this->model->where('category_id', $categoryId)->with( $this->relations )->orderBy( 'id', 'DESC' )->get();
        }

        return $this->model->where('category_id', $categoryId)->orderBy( 'id', 'DESC' )->get();
    }

}
