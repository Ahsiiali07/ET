<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Services\EventCategoryService;
use Illuminate\Http\JsonResponse;

class EventCategoryController extends Controller
{
    /**
     * @var EventCategoryService $service
     */
    private $service;

    public function __construct()
    {
        $this->service = new EventCategoryService();
    }

    /**
     * @return JsonResponse
     */

    public function get(): JsonResponse
    {
        $res = $this->service->getAll(10);

        if ($res) {

            return $this->successResponse(trans('Operation Successful!'), $res);
        }
        return $this->parametersInvalidResponse();

    }
}
