<?php

namespace App\Http\Controllers\API;

use App\Forms\Cart\CreateCartForm;
use App\Models\Event;
use App\Models\User;
use App\Services\EventService;
use App\Services\FavoriteService;
use App\Services\ServiceService;
use Auth;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

/**
 * Class FavoriteController
 * @package App\Http\Controllers\API
 */
class FavoriteController extends Controller {

    /**
     * @var FavoriteService $favoriteService
     */
    private $favoriteService;

    /**
     * FavoriteController constructor.
     */
    public function __construct() {
        $this->favoriteService = new FavoriteService();
        $this->eventService = new EventService();
    }

    /**
     * @param $event_id
     *
     * @return JsonResponse
     */
    public function favoriteUnFavorite( $event_id ): JsonResponse
    {

        if ( Auth::check() ) {
            $userId  = auth()->id();
            if ( isset( $event_id ) ) {
                if ( $ser = $this->eventService->findById($event_id) ) {

                    $item = $this->favoriteService->findFirst( [
                        'user_id'    => auth()->id(),
                        'event_id' => $event_id,
                    ] );

                    if ( $item ) {
                        $res = $this->favoriteService->removeFromFavorite( $userId, $event_id );
                        if ( $res ) {
                            return $this->successResponse( 'Event removed from favorites successfully!' );
                        }

                        return $this->parametersInvalidResponse( 'Error: event not removed from favorites!' );
                    }

                    $res = $this->favoriteService->addToFavorite( $userId, $event_id );

                    if ( $res ) {
                        return $this->successResponse( 'Event added to favorites successfully!' );
                    }

                    return $this->parametersInvalidResponse( 'Error: event not added from favorites!' );
                }

                return $this->successResponse( 'No Event Found!' );
            }

            return $this->parametersInvalidResponse();
        }

        return $this->unAuthorizedResponse();
    }

    /**
     * @return JsonResponse
     */
    public function getAllAgainstUser() {
        if ( Auth::check() ) {
            $items = $this->favoriteService->get(
                [
                    'user_id' => auth()->id(),
                ]
            );

            if ( $items && count( $items ) > 0 ) {
                return $this->successResponse(
                    null,
                    $items->load( 'user', 'event', 'event.category' )
                );
            }

            return $this->parametersInvalidResponse( 'No Items Found!' );
        }

        return $this->unAuthorizedResponse();
    }


}
