<?php

namespace App\Http\Controllers\API;


use App\Services\NewsService;
use Auth;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class NewsController extends Controller {
    /**
     * @var NewsService $service
     */
    private $service;
    private $relation = [];


    public function __construct() {
        $this->service = new NewsService();
    }

    /**
     * @return JsonResponse
     */

    public function get(): JsonResponse {
        $res = $this->service->getAll(10);

        if ( $res ) {

            return $this->successResponse( trans( 'Operation Successful!' ), $res );
        }

        return $this->parametersInvalidResponse();
    }

    /**
     * @return JsonResponse
     */
    public function getByCategory( $categoryId ) {
        $item = $this->service->getByCategory( $categoryId, 10 );

        if ( count( $item ) > 0 ) {

            return $this->successResponse( null, $item );
        }

        return $this->successResponse( 'No Record Found!' );

    }

    /**
     * @param $id
     *
     * @return JsonResponse
     */

    public function fetch( $id ) {
        $item = $this->service->findById( $id );
        if ( $item ) {
            $data['item'] = $item;
            $data['related'] = $this->service->getRelated( $item );

            return $this->successResponse( trans( 'Operation Successful!' ), $data );
        }

        return $this->parametersInvalidResponse();
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function filter( Request $request ): JsonResponse {
        $services = $this->service->filter( $request->all(), $request->per_page ?? null );

        if ( $services ) {

            return $this->successResponse( null, $services->load( $this->relation ) );
        }

        return $this->successResponse( 'No Article Found!' );
    }
}
