<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Services\PublicationService;
use Auth;
use Illuminate\Http\JsonResponse;

class PublicationController extends Controller {
    /** @var PublicationService $service */
    private $service;

    public function __construct() {
        $this->service = new PublicationService();
    }

    /**
     * @return JsonResponse
     */

    public function get(): JsonResponse {
        $res = $this->service->getAll( 10 );

        if ( $res ) {

            return $this->successResponse( trans( 'Operation Successful!' ), $res );
        }

        return $this->parametersInvalidResponse();

    }

    /**
     * @param $id
     *
     * @return JsonResponse
     */

    public function fetch( $id ): JsonResponse {
        $item = $this->service->findById( $id );
        if ( $item ) {
            $data['item']    = $item;
            $data['related'] = $this->service->getRelated( $item );

            return $this->successResponse( trans( 'Operation Successful!' ), $data );
        }

        return $this->parametersInvalidResponse();
    }

    /**
     * @return JsonResponse
     */
    public function lastWeekAll(): JsonResponse {

        $res = $this->service->lastWeekAll();

        if ( $res ) {

            return $this->successResponse( trans( 'Record Found!' ), $res );

        }

        return $this->parametersInvalidResponse();
    }

    /**
     * @return JsonResponse
     */
    public function lastMonthAll(): JsonResponse {

        $res = $this->service->lastMonthAll();

        if ( $res ) {

            return $this->successResponse( trans( 'Record Found!' ), $res );

        }

        return $this->parametersInvalidResponse();
    }

    /**
     * @return JsonResponse
     */
    public function getByCategory( $categoryId ) {
        $item = $this->service->getByCategory( $categoryId, 10 );

        if ( count( $item ) > 0 ) {

            return $this->successResponse( null, $item );
        }

        return $this->successResponse( 'No Record Found!' );
    }
}
