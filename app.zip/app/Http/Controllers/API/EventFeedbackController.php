<?php

namespace App\Http\Controllers\API;

use App\Forms\Ads\CreateAdsForm;
use App\Http\Controllers\Controller;
use App\Models\EventFeedback;
use App\Services\EventFeedbackService;
use App\Services\EventService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EventFeedbackController extends Controller {
    /**
     * @var EventFeedbackService $eventfeedbackService
     */
    private $eventFeedbackService;

    /**
     * @var EventService $eventService
     */
    private $eventService;

    /**
     * EventFeedbackController constructor.
     */
    public function __construct() {
        $this->eventFeedbackService = new EventFeedbackService();
        $this->eventService         = new EventService();
    }


    /**
     * @param Request $request
     * @param $event_id
     *
     * @return JsonResponse
     */
    public function addfeedback( Request $request, $event_id ): JsonResponse {

        if ( Auth::check() ) {
            $userId = auth()->id();
            if ( isset( $event_id ) ) {
                if ( $this->eventService->findById( $event_id ) ) {

                    $res = $this->eventFeedbackService->addFeedback( $userId, $event_id, $request['feedback'] );
                    if ( $res ) {
                        return $this->successResponse( 'Event Feedback added successfully!' );
                    }

                    return $this->parametersInvalidResponse( 'Error: event not added from favorites!' );
                }

                return $this->successResponse( 'No Event Found!' );
            }

            return $this->parametersInvalidResponse();
        }

        return $this->unAuthorizedResponse();
    }
}
