<?php

namespace App\Http\Controllers\Web;

use App\Forms\AdCategory\CreateAdCategoryForm;
use App\Forms\AdCategory\UpdateAdCategoryForm;
use App\Http\Controllers\Controller;
use App\Services\AdCategoryService;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Redirector;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Session;

class AdCategoryController extends Controller {

    /** @var AdCategoryService */
    private $service;

    /** @var string */
    private $backRoute;

    /**
     *  AdCategoryController constructor.
     */
    public function __construct() {
        $this->middleware( 'auth' );
        $this->service = new AdCategoryService();
        $this->backRoute = '/ad-category';
    }

    /**
     * @return Application|Factory|View
     */

    public function index() {
        return view( 'ad_category.index' )
            ->with( [
                'items' => $this->service->getAll( 20 ),
            ] );
    }

    /**
     * @return Application|Factory|View
     */
    public function create() {
        return view( 'ad_category.create' );
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     * @throws ValidationException
     */

    public function store( Request $request ): JsonResponse {
        $form = new CreateAdCategoryForm();
        $form->loadFromArray( $request->all() );
        $item = $this->service->store( $form );
        $msg  = 'Ad Category added successfully!';
        Session::flash( 'success', $msg );

        return response()->json(
            [
                'type' => 'success',
                'msg'  => $msg,
                'data' => $item
            ]
        );
    }

    /**
     * @param $id
     *
     * @return Application|Factory|View
     */
    public function edit( $id ) {
        return view( 'ad_category.edit' )
            ->with( [
                'item' => $this->service->findById( $id )
            ] );
    }

    /**
     * @param Request $request
     * @param $id
     *
     * @return JsonResponse
     * @throws ValidationException
     */
    public function update( Request $request, $id ): JsonResponse {
        $form = new UpdateAdCategoryForm();
        $form->loadFromArray( $request->all() );
        $items = $this->service->update( $form, $id );

        $msg = 'Ad Category updated successfully!';
        Session::flash( 'success', $msg );

        return response()->json(
            [
                'type' => 'success',
                'msg'  => $msg,
                'data' => $items
            ]
        );
    }

    /**
     * @param $id
     *
     * @return Application|Factory|View
     */

    public function show( $id ) {
        return view( 'ad_category.show' )
            ->with( [
                'item' => $this->service->findById( $id )
            ] );
    }

    /**
     * @param $id
     *
     * @return Application|RedirectResponse|Redirector
     */

    public function destroy( $id ) {
        $this->service->remove( $id );
        // Set flash
        Session::flash( 'success', 'Successfully Removed!' );

        return redirect( $this->backRoute );
    }
}
