<?php

namespace App\Http\Controllers\API;

use App\Forms\Ads\CreateAdsForm;
use App\Forms\Ads\UpdateAdsForm;
use App\Http\Controllers\Controller;
use App\Services\AdService;
use Auth;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\ValidationException;

class AdController extends Controller {

    /** @var AdService $service */
    private $service;

    public function __construct() {
        $this->service = new AdService();
    }

    /**
     * @return JsonResponse
     */

    public function get(): JsonResponse {
        $res = $this->service->getAll(10);

        if ( $res ) {

            return $this->successResponse( trans( 'Operation Successful!' ), $res );
        }

        return $this->parametersInvalidResponse();

    }

    /**
     * @param $id
     *
     * @return JsonResponse
     */

    public function fetch( $id ): JsonResponse {
        $item = $this->service->findById( $id );
        if ( $item ) {
            return $this->successResponse( trans( 'Operation Successful!' ), $item );
        }

        return $this->parametersInvalidResponse();
    }

    /**
     *
     * @param Request $request
     *
     * @return JsonResponse
     * @throws ValidationException
     */
    public function store( Request $request ): JsonResponse {
        $form = new CreateAdsForm();
        $form->loadFromArray( $request->all() );
        $item = $this->service->store( $form );
        $msg  = 'Ads added successfully!';
        Session::flash( 'success', $msg );

        if ( $item ) {
            return $this->successResponse( [
                'type' => 'success',
                'msg'  => $msg,
                'data' => $item
            ] );
        }

        return $this->parametersInvalidResponse();
    }

    /**
     * @param Request $request
     * @param $id
     *
     * @return JsonResponse
     * @throws ValidationException
     */

    public function update( Request $request, $id ): JsonResponse {
        $form = new UpdateAdsForm();
        $form->loadFromArray( $request->all() );
        $item = $this->service->update( $form, $id );
        $msg  = 'Ads updated successfully!';
        Session::flash( 'success', $msg );

        if ( $item ) {
            return $this->successResponse( [
                'type' => 'success',
                'msg'  => $msg,
                'data' => $item
            ] );
        }

        return $this->parametersInvalidResponse();
    }

    /**
     * @param $id
     *
     * @return JsonResponse
     */

    public function destroy( $id ): JsonResponse {
        $item = $this->service->remove( $id );
        $msg  = 'Successfully Removed!';

        if ( $item ) {

            return $this->successResponse( trans( 'Deleted Successfully!' ), $msg );
        }

        return $this->parametersInvalidResponse();
    }

    /**
     * @return JsonResponse
     */
    public function getByCategory( $categoryId ) {
        $item = $this->service->getByCategory( $categoryId, 10 );

        if ( count( $item ) > 0 ) {

            return $this->successResponse( null, $item );
        }

        return $this->successResponse( 'No Record Found!' );
        
    }
}
