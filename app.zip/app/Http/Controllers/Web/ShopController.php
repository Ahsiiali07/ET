<?php

namespace App\Http\Controllers\Web;
use App\Forms\Shops\CreateShopsForm;
use App\Forms\Shops\UpdateShopsForm;
use App\Http\Controllers\Controller;
use App\Services\ShopService;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class ShopController extends Controller
{
    /** @var ShopService */
    private $service;
    /** @var string  */
    private $backRoute = '/shops';

    /**
     *  PublicationController constructor.
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->service = new ShopService();
    }

    /**
     * @return Application|Factory|View
     */

    public function index()
    {
        return view('shops.index')
            ->with([
                'items' => $this->service->getAll(20),
            ]);
    }

    /**
     * @return Application|Factory|View
     */
    public function create()
    {
        return view('shops.create');
    }

    /**
     * @param Request $request
     * @return JsonResponse
     * @throws ValidationException
     */
    public function store(Request $request): JsonResponse
    {
        $form = new CreateShopsForm();
        $form->loadFromArray($request->all());

        $item = $this->service->store($form);
        $msg = 'Shop added successfully!';
        Session::flash('success',$msg);
        return response()->json(
            [
                'type' => 'success',
                'msg' => $msg,
                'data' => $item
            ]
        );
    }

    /**
     * @param $id
     * @return Application|Factory|View
     */
    public function show($id)
    {
        return view('shops.show')->with([
            'item'=>$this->service->findById($id)
        ]);
    }

    /**
     * @param $id
     * @return Application|Factory|View
     */
    public function edit($id)
    {
        return view('shops.edit')
            ->with([
                'item' => $this->service->findById($id)
            ]);
    }

    /**
     * @param Request $request
     * @param $id
     * @return JsonResponse
     * @throws ValidationException
     */
    public function update(Request $request, $id): JsonResponse
    {
        $form = new UpdateShopsForm();
        $form->loadFromArray($request->all());
        $items = $this->service->update($form, $id);

        $msg = 'Shops updated successfully!';
        Session::flash('success', $msg);

        return response()->json(
            [
                'type' => 'success',
                'msg' => $msg,
                'data' => $items
            ]
        );
    }

    /**
     * @param $id
     * @return Application|RedirectResponse|Redirector
     */
    public function destroy($id)
    {
        $this->service->remove($id);
        $msg='Deleted Successfully';

        Session::flash('success', $msg);


        return redirect($this->backRoute);
    }
}
