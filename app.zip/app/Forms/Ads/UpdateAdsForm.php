<?php

namespace App\Forms\Ads;
/**
 * @property string $title
 * @property string $phone
 * @property string $description_en
 * @property string $email
 * @property string $image_url
 * @property string $category_id
 */
class UpdateAdsForm extends \App\Forms\BaseForm {

    /* @var $title */
    public $title;

    /* @var $phone */
    public $phone;

    /* @var $description */
    public $description;

    /* @var $email */
    public $email;

    /* @var $image_url */
    public $image_url;

    /* @var $category_id */
    public $category_id;

    /* @var $user_id */
    public $user_id;

    /**
     * @inheritDoc
     */
    public function toArray() {
        return [
            'title'       => $this->title,
            'phone'       => $this->phone,
            'description' => $this->description,
            'email'       => $this->email,
            'image_url'   => $this->image_url,
            'category_id' => $this->category_id,
            'user_id'     => $this->user_id,
        ];
    }

    /**
     * @inheritDoc
     */
    public function rules() {
        return [
        ];
    }
}
