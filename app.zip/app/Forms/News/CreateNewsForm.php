<?php

namespace App\Forms\News;

use App\Forms\BaseForm;

/**
 * @property string $name_en
 * @property string $name_sp
 * @property string $description_en
 * @property string $description_sp
 * @property string $author_en
 * @property string $author_sp
 * @property int $category_id
 */
class CreateNewsForm extends BaseForm {

    /* @var $name_en */
    public $name_en;

    /* @var $name_sp */
    public $name_sp;

    /* @var $description_en */
    public $description_en;

    /* @var $description_sp */
    public $description_sp;

    /* @var $author_en */
    public $author_en;

    /* @var $author_sp */
    public $author_sp;

    /* @var $category_id */
    public $category_id;

    /**
     * @return array
     */

    public function toArray() {
        return [
            'name_en'        => $this->name_en,
            'name_sp'        => $this->name_sp,
            'description_en' => $this->description_en,
            'description_sp' => $this->description_sp,
            'author_en'      => $this->author_en,
            'author_sp'      => $this->author_sp,
            'category_id'    => $this->category_id,

        ];
    }

    /**
     * @return string[]
     */
    public function rules() {
        return [
            'name_en'        => 'required',
            'name_sp'        => 'required',
            'description_en' => 'required',
            'description_sp' => 'required',
            'author_en'      => 'required',
            'author_sp'      => 'required',

        ];
    }
}
