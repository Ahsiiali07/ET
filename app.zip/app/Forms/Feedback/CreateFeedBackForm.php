<?php

namespace App\Forms\Feedback;
/**
 * @property int $event_id
 * @property int $user_id
 * @property string $feedback
 * @property string $description_en
 * @property string $description_sp
 */
class CreateFeedBackForm extends \App\Forms\BaseForm {

    /* @var $event_id */
    public $event_id;

    /* @var $user_id */
    public $user_id;

    /* @var $feedback */
    public $feedback;


    /**
     * @inheritDoc
     */
    public function toArray() {
        return [
            'event_id' => $this->event_id,
            'user_id'  => $this->user_id,
            'feedback' => $this->feedback,

        ];
    }

    /**
     * @inheritDoc
     */
    public function rules() {
        return [
            'event_id' => 'required',
            'user_id'  => 'required',
            'feedback' => 'required'
        ];
    }
}
