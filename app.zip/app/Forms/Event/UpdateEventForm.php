<?php

namespace App\Forms\Event;
/**
 * @property string $name_en
 * @property string $name_sp
 * @property string $description_en
 * @property string $description_sp
 * @property string $location
 * @property int $category_id
 * @property string $images
 * @property string $feedback
 */
class UpdateEventForm extends \App\Forms\BaseForm {
    /* @var $name_en */
    public $name_en;

    /* @var $name_sp */
    public $name_sp;

    /* @var $description_en */
    public $description_en;

    /* @var $description_sp */
    public $description_sp;

    /* @var $location */
    public $location;

    /* @var $category_id */
    public $category_id;

    /* @var $images */
    public $images;

    /* @var $feedback */
    public $feedback;


    /**
     * @inheritDoc
     */
    public function toArray() {
        return [
            'name_en'        => $this->name_en,
            'name_sp'        => $this->name_sp,
            'description_en' => $this->description_en,
            'description_sp' => $this->description_sp,
            'location'       => $this->location,
            'category_id'    => $this->category_id,
            'images'         => $this->images,
        ];
    }

    /**
     * @inheritDoc
     */
    public function rules() {
        return [
        ];
    }
}
